/* 
 * File:   main.cpp
 * Author: Robel Woldeamanuel
 * Created on September 21, 2017, 12:30 PM
 */

//System Libraries
#include <cmath>        //Power function
#include <iostream>     //cout/cin
#include <iomanip>      //formatting
using namespace std;

//User Libraries

//Global Constants

//Function prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int numYear;
    float prcItem, ratIfl, totPric;//Rate_of_inflation_in_percentage

    //Input values
    cout<<"This calculates the price given inflation"<<endl;
    cout<<"Input the price of the item $'s"<<endl;
    cin>>prcItem; //price_of_item
    cout<<"Input the number of years for inflation"<<endl;
    cin>>numYear; //number_of_year
    cout<<"Input the rate of inflation %"<<endl;
    cin>>ratIfl; //rate_of_inflation_in_fraction
            
    //Perform calculations
    ratIfl/=100;
    totPric=prcItem*pow(1+ratIfl,numYear);
            
    //Output the inputs and the results
    cout<<fixed<<setprecision(2)<<endl;
    cout<<"The Price of the item Year 0 = $"<<prcItem<<endl;
    cout<<"The Number of years          =  "<<numYear<<endl;
    cout<<"The rate of Inflation        =  "<<ratIfl<<"%"<<endl;
    cout<<"The future price             = $"<<totPric<<endl;
    
    //Exit the program
    return 0;
}