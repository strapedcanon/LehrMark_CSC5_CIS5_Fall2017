/* 
 * File:   main.cpp
 * Author: robel woldeamanuel
 * Created on Sep 26,2017 12:46 AM
 * Purpose:  Creating a class template
 */

//System Libraries
#include <iostream>     //Input/Output Stream Library
#include <cmath>
using namespace std;    //Standard Name-space under which System Libraries reside

//User Libraries

//Global Constants - Not variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv)
{
    //Declare Variables
    int x,sum=0, sumPos=0, sumNeg=0, totNum=10;
    float sumAvg, sumNavg,sumPavg;
    //Initialize Variables
    
    //Input Data/Variables
    cout<<"sum 10 numbers + or - and get the Pos and Neg sum"<<endl;
    cout<<"input a number"<<endl;
    cin>>x;
    //Process or map the inputs to the outputs
    sumPos+=(x>0?x:0);
    sumNeg+=(x<0?x:0);
    
       cout<<"input a number"<<endl;
    cin>>x;
    //Process or map the inputs to the outputs
    sumPos+=(x>0?x:0);
    sumNeg+=(x<0?x:0);
    
       cout<<"input a number"<<endl;
    cin>>x;
    //Process or map the inputs to the outputs
    sumPos+=(x>0?x:0);
    sumNeg+=(x<0?x:0);
    
       cout<<"input a number"<<endl;
    cin>>x;
    //Process or map the inputs to the outputs
    sumPos+=(x>0?x:0);
    sumNeg+=(x<0?x:0);
    
       cout<<"input a number"<<endl;
    cin>>x;
    //Process or map the inputs to the outputs
    sumPos+=(x>0?x:0);
    sumNeg+=(x<0?x:0);
    
       cout<<"input a number"<<endl;
    cin>>x;
    //Process or map the inputs to the outputs
    sumPos+=(x>0?x:0);
    sumNeg+=(x<0?x:0);
    
       cout<<"input a number"<<endl;
    cin>>x;
    //Process or map the inputs to the outputs
    sumPos+=(x>0?x:0);
    sumNeg+=(x<0?x:0);
    
       cout<<"input a number"<<endl;
    cin>>x;
    //Process or map the inputs to the outputs
    sumPos+=(x>0?x:0);
    sumNeg+=(x<0?x:0);
    
       cout<<"input a number"<<endl;
    cin>>x;
    //Process or map the inputs to the outputs
    sumPos+=(x>0?x:0);
    sumNeg+=(x<0?x:0);
    
       cout<<"input a number"<<endl;
    cin>>x;
    //Process or map the inputs to the outputs
    sumPos+=(x>0?x:0);
    sumNeg+=(x<0?x:0);
    //calculate total
    sum=sumPos+sumNeg;
    sumAvg=sum/totNum;
    //Display/Output all pertinent variables
    cout<<"the positive sum ="<<sumPos<<endl;
    cout<<"the negative sum ="<<sumNeg<<endl;
    cout<<"the total sum ="<<sum<<endl;
    cout<<"the average sum="<<sumAvg<<endl;
    cout<<"the positive average sum="<<sumPavg<<endl;
    cout<<"the negative average sum="<<sumNavg<<endl;
    //Exit the program
    return 0;
}