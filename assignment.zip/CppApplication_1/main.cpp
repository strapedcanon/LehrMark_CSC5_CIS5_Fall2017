/* 
 * File:   main.cpp
 * Author: robel woldeamanuel
 * Created on Sep 26,2017 02:35 PM
 * Purpose:  Creating a class template
 */

//System Libraries
#include <iostream>//Input/Output Stream Library
#include <cmath>
using namespace std;    //Standard Name-space under which System Libraries reside

//User Libraries

//Global Constants - Not variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float velcity,T, t;
    //Initialize Variables
    
    //Input Data/Variables
    cout<<"give  two estimate temperature to get the velocity "<<endl;
    cout<<"input temperature in Celsius"<<endl;
    cin>>T;
    
    cout<<"input temperature in Celsius"<<endl;
    cin>>t;
    //Process or map the inputs to the outputs
   
    //calculate total
    velcity=331.3+0.61*t;
    velcity=331.3+0.61*T;
    //Display/Output all pertinent variables
    cout<<"at"<<" "<<t<<" "<<"degrees the velocity of the sound is"<<"  "<<velcity<<"m/s"<<endl;
    cout<<"at"<<" "<<T<<" "<<"degrees the velocity of the sound is"<<"  "<<velcity<<"m/s"<<endl;
    //Exit the program
    return 0;
}

